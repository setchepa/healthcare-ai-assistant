# fastapi_server.py content (see full implementation in your original script)
