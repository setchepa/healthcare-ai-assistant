from app.healthcare_agent import run_healthcare_assistant
import asyncio

if __name__ == "__main__":
    asyncio.run(run_healthcare_assistant())
